# Zirve Trans EX1 Portal (V1.4)

Yeni özellikler:
1) Çoklu dil TR/EN/FR toggle (login, müşteri, admin panelleri)
2) Evraklara otomatik isim standardı (display_name):
   - Format: REQUESTID_source_timestamp_original.ext
3) Kullanıcı yönetimi / fiyatlandırma:
   - Admin panelinde kullanıcı tablosu
   - Fiyat/Talep, para birimi, aktif-pasif
   - Pasif kullanıcı giriş yapamaz.

Kurulum:
npm install
npm start
