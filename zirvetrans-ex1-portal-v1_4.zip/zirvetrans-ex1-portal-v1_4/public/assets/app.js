const API = location.origin + '/api';
function setToken(t){ localStorage.setItem('token', t); }
function getToken(){ return localStorage.getItem('token'); }
function setUser(u){ localStorage.setItem('user', JSON.stringify(u)); }
function getUser(){ try { return JSON.parse(localStorage.getItem('user')); } catch(e){ return null; } }
function authHeader(){ return { 'Authorization': 'Bearer ' + getToken() }; }
function logout(){ localStorage.clear(); location.href='/login.html'; }

const SUPPORT_PHONE = (localStorage.getItem('support_phone') || '905000000000');

// ---------- i18n ----------
const I18N = { /* same as in v1.4 doc; shortened in file for speed? no keep full */
  tr: {
    app_title:"Zirve Trans EX1 Portal",
    brand_login:"ZIRVE TRANS | EX1 Portal",
    brand_customer:"ZIRVE TRANS | Müşteri Paneli",
    brand_admin:"ZIRVE TRANS | Admin Paneli",
    login_title:"Giriş Yap", login_btn:"Giriş", register_btn:"Kayıt Ol",
    register_title:"Kayıt Ol", register_complete:"Kaydı Tamamla",
    cancel:"Vazgeç",
    phone:"Telefon", password:"Şifre", email:"E-posta",
    email_optional:"E-posta (opsiyonel)",
    company_name:"Firma Adı", full_name:"Yetkili Ad Soyad",
    customer_panel_title:"EX1 Talep Paneli", admin_panel_title:"Admin | EX1 Portal",
    wa_support:"WhatsApp Canlı Destek", wa_support_note:"Operasyon ekibimiz online. Hızlı yardım için yazabilirsiniz.", wa_write:"WhatsApp'a Yaz",
    new_request:"Yeni EX1 Evrak Talebi", exit_office:"Çıkış Kapısı / Gümrük Ofisi", eori_number:"EORI Numarası", notes_optional:"Not (opsiyonel)",
    create_request:"Talep Oluştur", upload_docs:"Evrak Yükle", upload_btn:"Dosyaları Yükle", upload_note:"PDF, JPG, PNG, XLSX vb. yükleyebilirsiniz. Maks. 10 dosya.",
    past_requests:"Geçmiş Taleplerim", past_note:"Her talepte “Evraklarım” butonuna basarak hem kendi yüklediklerinizi hem de adminin geri yüklediği evrakları indirebilirsiniz.",
    date:"Tarih", docs:"Evrak", status:"Durum", process:"İşlem",
    all_requests:"Tüm Talepler", admin_note:"Her satırda “Evraklar” butonu ile müşteri evraklarını indirip işlem sonrası kendi evraklarınızı geri yükleyebilirsiniz.",
    logout:"Çıkış",
    user_management:"Kullanıcı Yönetimi / Fiyatlandırma",
    user_note:"Buradan müşterilerin fiyatını, para birimini ve hesabın aktif/pasif durumunu yönetebilirsiniz.",
    price_per_request:"Fiyat / Talep",
    currency:"Para Birimi",
    active:"Aktif",
    save:"Kaydet",
    my_docs:"Evraklarım",
    customer_docs:"Yüklediğiniz evraklar",
    admin_docs:"Zirve Trans tarafından yüklenen evraklar",
    no_docs:"Evrak yok",
    upload_after:"İşlem sonrası evrak yükle",
    admin_upload_btn:"Admin Evraklarını Yükle",
  },
  en: {
    app_title:"Zirve Trans EX1 Portal",
    brand_login:"ZIRVE TRANS | EX1 Portal",
    brand_customer:"ZIRVE TRANS | Customer Panel",
    brand_admin:"ZIRVE TRANS | Admin Panel",
    login_title:"Sign In", login_btn:"Sign In", register_btn:"Register",
    register_title:"Register", register_complete:"Complete Registration",
    cancel:"Cancel",
    phone:"Phone", password:"Password", email:"Email",
    email_optional:"Email (optional)",
    company_name:"Company Name", full_name:"Contact Person",
    customer_panel_title:"EX1 Request Panel", admin_panel_title:"Admin | EX1 Portal",
    wa_support:"WhatsApp Live Support", wa_support_note:"Our operations team is online. Message us for quick help.", wa_write:"Chat on WhatsApp",
    new_request:"New EX1 Document Request", exit_office:"Exit Office / Customs", eori_number:"EORI Number", notes_optional:"Notes (optional)",
    create_request:"Create Request", upload_docs:"Upload Documents", upload_btn:"Upload Files", upload_note:"You can upload PDF, JPG, PNG, XLSX etc. Max 10 files.",
    past_requests:"My Previous Requests", past_note:"Click “My Documents” to download your uploads and admin-returned documents.",
    date:"Date", docs:"Docs", status:"Status", process:"Action",
    all_requests:"All Requests", admin_note:"Use 'Documents' to download customer files and upload processed files back.",
    logout:"Logout",
    user_management:"User Management / Pricing",
    user_note:"Manage customer pricing, currency, and active/passive status here.",
    price_per_request:"Price / Request",
    currency:"Currency",
    active:"Active",
    save:"Save",
    my_docs:"My Documents",
    customer_docs:"Your uploaded documents",
    admin_docs:"Documents uploaded by Zirve Trans",
    no_docs:"No documents",
    upload_after:"Upload processed documents",
    admin_upload_btn:"Upload Admin Docs",
  },
  fr: {
    app_title:"Portail EX1 Zirve Trans",
    brand_login:"ZIRVE TRANS | Portail EX1",
    brand_customer:"ZIRVE TRANS | Espace Client",
    brand_admin:"ZIRVE TRANS | Espace Admin",
    login_title:"Connexion", login_btn:"Connexion", register_btn:"Inscription",
    register_title:"Inscription", register_complete:"Valider l'inscription",
    cancel:"Annuler",
    phone:"Téléphone", password:"Mot de passe", email:"E-mail",
    email_optional:"E-mail (optionnel)",
    company_name:"Société", full_name:"Contact",
    customer_panel_title:"Demandes EX1", admin_panel_title:"Admin | Portail EX1",
    wa_support:"Support WhatsApp", wa_support_note:"Notre équipe est en ligne. Écrivez-nous pour une aide rapide.", wa_write:"Écrire sur WhatsApp",
    new_request:"Nouvelle demande de documents EX1", exit_office:"Bureau de sortie / Douane", eori_number:"Numéro EORI", notes_optional:"Note (optionnel)",
    create_request:"Créer la demande", upload_docs:"Téléverser des documents", upload_btn:"Téléverser", upload_note:"PDF, JPG, PNG, XLSX etc. Max 10 fichiers.",
    past_requests:"Mes demandes", past_note:"Cliquez sur « Mes documents » pour télécharger vos fichiers et ceux de l’admin.",
    date:"Date", docs:"Docs", status:"Statut", process:"Action",
    all_requests:"Toutes les demandes", admin_note:"Téléchargez les fichiers clients et renvoyez les documents traités.",
    logout:"Déconnexion",
    user_management:"Gestion utilisateurs / Tarification",
    user_note:"Gérez les tarifs, la devise et l’activation des comptes ici.",
    price_per_request:"Prix / Demande",
    currency:"Devise",
    active:"Actif",
    save:"Enregistrer",
    my_docs:"Mes documents",
    customer_docs:"Vos documents téléversés",
    admin_docs:"Documents envoyés par Zirve Trans",
    no_docs:"Aucun document",
    upload_after:"Téléverser documents traités",
    admin_upload_btn:"Téléverser (Admin)",
  }
};

function getLang(){ return localStorage.getItem('lang') || 'tr'; }
function setLang(l){ localStorage.setItem('lang', l); applyI18n(); }
function applyI18n(){
  const lang = getLang();
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    const val = I18N[lang]?.[key];
    if(val) el.textContent = val;
  });
  ['tr','en','fr'].forEach(k=>{
    const b = document.getElementById('lang-'+k);
    if(b) b.classList.toggle('active', k===lang);
  });
}
// ---------- auth UI ----------
function toggleRegister(){
  const card = document.getElementById('registerCard');
  if(card) card.style.display = (card.style.display==='none'?'block':'none');
}
async function register(){
  const body = {
    company_name: document.getElementById('regCompany').value.trim(),
    full_name: document.getElementById('regName').value.trim(),
    phone: document.getElementById('regPhone').value.trim(),
    email: document.getElementById('regEmail').value.trim(),
    password: document.getElementById('regPass').value
  };
  const msg = document.getElementById('regMsg');
  msg.textContent='';
  const r = await fetch(API+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j = await r.json();
  if(!r.ok) msg.textContent = j.error || 'Error';
  else { msg.textContent='OK'; }
}
async function login(){
  const body = {
    phone: document.getElementById('loginPhone').value.trim(),
    password: document.getElementById('loginPass').value
  };
  const msg = document.getElementById('loginMsg');
  msg.textContent='';
  const r = await fetch(API+'/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j = await r.json();
  if(!r.ok) msg.textContent = j.error || 'Error';
  else {
    setToken(j.token);
    setUser({ role:j.role, full_name:j.full_name, company_name:j.company_name });
    location.href = j.role==='admin' ? '/admin.html' : '/dashboard.html';
  }
}
function statusBadge(s){ return `<span class="badge ${s}">${s}</span>`; }

let currentRequestId = null;

// ---------------- Customer ----------------
async function initDashboard(){
  const u = getUser();
  if(!u || !getToken()) return logout();
  document.getElementById('who').textContent = u.company_name + ' / ' + u.full_name;

  const wa = document.getElementById('waLink');
  if (wa){
    const text = encodeURIComponent(`Merhaba, EX1 talebim hakkında destek rica ediyorum. Firma: ${u.company_name}`);
    wa.href = `https://wa.me/${SUPPORT_PHONE}?text=${text}`;
  }
  await loadMine();
  applyI18n();
}
async function createRequest(){
  const body = {
    exit_office: document.getElementById('exitOffice').value.trim(),
    eori_number: document.getElementById('eoriNumber').value.trim(),
    notes: document.getElementById('notes').value.trim()
  };
  const msg = document.getElementById('createMsg');
  msg.textContent='';
  const r = await fetch(API+'/requests',{method:'POST',headers:{'Content-Type':'application/json',...authHeader()},body:JSON.stringify(body)});
  const j = await r.json();
  if(!r.ok) msg.textContent = j.error || 'Error';
  else {
    currentRequestId = j.id;
    msg.textContent = 'OK';
    document.getElementById('uploadArea').style.display='block';
    await loadMine();
  }
}
async function uploadFiles(){
  if(!currentRequestId) return;
  const files = document.getElementById('files').files;
  if(!files.length) return;
  const fd = new FormData();
  for(const f of files) fd.append('files', f);
  const msg = document.getElementById('uploadMsg');
  msg.textContent='';
  const r = await fetch(API+`/requests/${currentRequestId}/documents`,{method:'POST',headers:authHeader(),body:fd});
  const j = await r.json();
  if(!r.ok) msg.textContent = j.error || 'Error';
  else { msg.textContent = `${j.uploaded}`; await loadMine(); }
}
async function loadMine(){
  const body = await (await fetch(API+'/requests/mine',{headers:authHeader()})).json();
  const tb = document.getElementById('reqTable');
  tb.innerHTML='';
  const t = I18N[getLang()];
  for(const r of body){
    const dt = new Date(r.created_at).toLocaleString();
    tb.innerHTML += `<tr id="crow-${r.id}">
      <td>${dt}</td>
      <td>${r.exit_office}</td>
      <td>${r.eori_number}</td>
      <td>${r.doc_count}</td>
      <td>${statusBadge(r.status)}</td>
      <td><button class="btn small secondary" onclick="toggleCustomerDocs('${r.id}')">${t.my_docs}</button></td>
    </tr>
    <tr id="cdocs-${r.id}" style="display:none">
      <td colspan="6">
        <div class="card" style="margin:8px 0">
          <h3>${t.docs}</h3>
          <div id="cdocsList-${r.id}" class="notice">...</div>
        </div>
      </td>
    </tr>`;
  }
  applyI18n();
}
async function toggleCustomerDocs(requestId){
  const tr = document.getElementById(`cdocs-${requestId}`);
  if(!tr) return;
  const isOpen = tr.style.display !== 'none';
  tr.style.display = isOpen ? 'none' : 'table-row';
  if(!isOpen) await loadCustomerDocs(requestId);
}
async function loadCustomerDocs(requestId){
  const listEl = document.getElementById(`cdocsList-${requestId}`);
  listEl.textContent = '...';
  const docs = await (await fetch(API+`/requests/${requestId}/documents`,{headers:authHeader()})).json();
  if(!Array.isArray(docs)){ listEl.textContent = docs.error || 'Error'; return; }

  const t = I18N[getLang()];
  const customerDocs = docs.filter(d=> (d.source||'customer')==='customer');
  const adminDocs = docs.filter(d=> d.source==='admin');

  const renderGroup = (title, arr) => {
    if(!arr.length) return `<p class="notice">${title}: ${t.no_docs}</p>`;
    return `<h4>${title}</h4><ul>` + arr.map(d=>{
      const dt = new Date(d.created_at).toLocaleString();
      const name = d.display_name || d.original_name;
      return `<li style="margin:4px 0">
        <a href="/api/requests/documents/${d.id}" target="_blank" download>${name}</a>
        <span class="notice"> (${dt})</span>
      </li>`;
    }).join('') + `</ul>`;
  };
  listEl.innerHTML = renderGroup(t.customer_docs, customerDocs)
     + '<hr/>' + renderGroup(t.admin_docs, adminDocs);
}

// ---------------- Admin ----------------
async function initAdmin(){
  const u = getUser();
  if(!u || u.role!=='admin' || !getToken()) return logout();
  document.getElementById('who').textContent = u.company_name + ' / ' + u.full_name;
  await loadAll();
  await loadUsers();
  applyI18n();
}
async function loadAll(){
  const rows = await (await fetch(API+'/requests',{headers:authHeader()})).json();
  const tb = document.getElementById('adminTable');
  tb.innerHTML='';
  const t = I18N[getLang()];
  for(const r of rows){
    const dt = new Date(r.created_at).toLocaleString();
    tb.innerHTML += `<tr id="row-${r.id}">
      <td>${dt}</td>
      <td>${r.company_name}</td>
      <td>${r.full_name}</td>
      <td>${r.phone}</td>
      <td>${r.exit_office}</td>
      <td>${r.eori_number}</td>
      <td>${r.doc_count}</td>
      <td>${statusBadge(r.status)}</td>
      <td class="flex">
        <button class="btn small secondary" onclick="toggleDocs('${r.id}')">${t.docs}</button>
        <select onchange="updateStatus('${r.id}', this.value)">
          ${['pending','in_review','approved','rejected','completed'].map(s=>`<option value="${s}" ${s===r.status?'selected':''}>${s}</option>`).join('')}
        </select>
      </td>
    </tr>
    <tr id="docs-${r.id}" style="display:none">
      <td colspan="9">
        <div class="card" style="margin:8px 0">
          <h3>${t.docs}</h3>
          <div id="docsList-${r.id}" class="notice">...</div>
          <hr/>
          <h3>${t.upload_after}</h3>
          <input id="adminFiles-${r.id}" type="file" multiple />
          <div class="flex" style="margin-top:6px">
            <button class="btn small" onclick="uploadAdminFiles('${r.id}')">${t.admin_upload_btn}</button>
            <span id="adminUploadMsg-${r.id}" class="notice"></span>
          </div>
        </div>
      </td>
    </tr>`;
  }
  applyI18n();
}
async function updateStatus(id, status){
  await fetch(API+`/requests/${id}/status`,{
    method:'PATCH',
    headers:{'Content-Type':'application/json',...authHeader()},
    body:JSON.stringify({status})
  });
}
async function toggleDocs(requestId){
  const tr = document.getElementById(`docs-${requestId}`);
  if(!tr) return;
  const isOpen = tr.style.display !== 'none';
  tr.style.display = isOpen ? 'none' : 'table-row';
  if(!isOpen){ await loadDocs(requestId); }
}
async function loadDocs(requestId){
  const listEl = document.getElementById(`docsList-${requestId}`);
  listEl.textContent = '...';
  const docs = await (await fetch(API+`/requests/${requestId}/documents`,{headers:authHeader()})).json();
  if(!Array.isArray(docs)){ listEl.textContent = docs.error || 'Error'; return; }
  const t = I18N[getLang()];
  const customerDocs = docs.filter(d=> (d.source||'customer')==='customer');
  const adminDocs = docs.filter(d=> d.source==='admin');
  const renderGroup = (title, arr) => {
    if(!arr.length) return `<p class="notice">${title}: ${t.no_docs}</p>`;
    return `<h4>${title}</h4><ul>` + arr.map(d=>{
      const dt = new Date(d.created_at).toLocaleString();
      const name = d.display_name || d.original_name;
      return `<li style="margin:4px 0">
        <a href="/api/requests/documents/${d.id}" target="_blank">${name}</a>
        <span class="notice"> (${dt})</span>
      </li>`;
    }).join('') + `</ul>`;
  };
  listEl.innerHTML = renderGroup(t.customer_docs, customerDocs)
     + '<hr/>' + renderGroup(t.admin_docs, adminDocs);
}
async function uploadAdminFiles(requestId){
  const input = document.getElementById(`adminFiles-${requestId}`);
  const msg = document.getElementById(`adminUploadMsg-${requestId}`);
  msg.textContent='';
  const files = input.files;
  if(!files.length){ msg.textContent='Select files'; return; }
  const fd = new FormData();
  for(const f of files) fd.append('files', f);
  const r = await fetch(API+`/requests/${requestId}/admin-documents`,{
    method:'POST',
    headers:authHeader(),
    body:fd
  });
  const j = await r.json();
  if(!r.ok) msg.textContent = j.error || 'Error';
  else {
    msg.textContent = `${j.uploaded}`;
    input.value='';
    await loadDocs(requestId);
  }
}

// ---------- Users/pricing ----------
async function loadUsers(){
  const rows = await (await fetch(API+'/users',{headers:authHeader()})).json();
  const tb = document.getElementById('usersTable');
  if(!tb) return;
  tb.innerHTML='';
  const t = I18N[getLang()];
  rows.filter(u=>u.role!=='admin').forEach(u=>{
    tb.innerHTML += `<tr>
      <td>${u.company_name||''}</td>
      <td>${u.full_name||''}</td>
      <td>${u.phone||''}</td>
      <td>${u.email||''}</td>
      <td><input id="price-${u.id}" type="number" step="0.01" value="${u.price_per_request||0}" style="max-width:120px"/></td>
      <td>
        <select id="cur-${u.id}">
          ${['EUR','USD','TRY'].map(c=>`<option ${c===u.currency?'selected':''}>${c}</option>`).join('')}
        </select>
      </td>
      <td style="text-align:center">
        <input id="act-${u.id}" type="checkbox" ${u.is_active? 'checked':''}/>
      </td>
      <td>
        <button class="btn small" onclick="saveUser('${u.id}')">${t.save}</button>
      </td>
    </tr>`;
  });
  applyI18n();
}
async function saveUser(id){
  const price = document.getElementById(`price-${id}`).value;
  const currency = document.getElementById(`cur-${id}`).value;
  const is_active = document.getElementById(`act-${id}`).checked;
  await fetch(API+`/users/${id}`,{
    method:'PATCH',
    headers:{'Content-Type':'application/json',...authHeader()},
    body:JSON.stringify({price_per_request:price, currency, is_active})
  });
  await loadUsers();
}
