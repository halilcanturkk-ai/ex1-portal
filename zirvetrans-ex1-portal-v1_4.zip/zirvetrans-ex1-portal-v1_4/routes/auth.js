const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const { run, get } = require('../db');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { company_name, full_name, phone, email, password } = req.body;
    if (!company_name || !full_name || !phone || !password) {
      return res.status(400).json({ error: 'Eksik alan var' });
    }
    const exists = await get(`SELECT id FROM users WHERE phone=?`, [phone]);
    if (exists) return res.status(409).json({ error: 'Bu telefon ile kayıt var' });

    const id = uuid();
    const passHash = await bcrypt.hash(password, 10);
    await run(
      `INSERT INTO users(id, company_name, full_name, phone, email, password_hash, role, created_at)
       VALUES(?,?,?,?,?,?,?,?)`,
      [id, company_name, full_name, phone, email || '', passHash, 'customer', new Date().toISOString()]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    const user = await get(`SELECT * FROM users WHERE phone=?`, [phone]);
    if (!user) return res.status(401).json({ error: 'Hatalı giriş' });
    if (user.is_active === 0) return res.status(403).json({ error: 'Hesap pasif' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Hatalı giriş' });

    const token = jwt.sign(
      { id: user.id, role: user.role, company_name: user.company_name, full_name: user.full_name },
      process.env.JWT_SECRET || 'dev_secret_change_me',
      { expiresIn: '7d' }
    );
    res.json({ token, role: user.role, full_name: user.full_name, company_name: user.company_name });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

module.exports = router;
