const express = require('express');
const { authRequired, adminOnly } = require('../middleware/auth');
const { all, run, get } = require('../db');

const router = express.Router();

router.get('/', authRequired, adminOnly, async (req, res) => {
  try {
    const rows = await all(`SELECT id, company_name, full_name, phone, email, role, price_per_request, currency, is_active, created_at
                            FROM users ORDER BY created_at DESC`);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.patch('/:id', authRequired, adminOnly, async (req, res) => {
  try {
    const { price_per_request, currency, is_active, role } = req.body;
    const user = await get(`SELECT id FROM users WHERE id=?`, [req.params.id]);
    if(!user) return res.status(404).json({ error: 'Kullanıcı yok' });

    const updates = [];
    const params = [];
    if(price_per_request !== undefined){ updates.push('price_per_request=?'); params.push(Number(price_per_request)||0); }
    if(currency !== undefined){ updates.push('currency=?'); params.push(String(currency||'EUR')); }
    if(is_active !== undefined){ updates.push('is_active=?'); params.push(is_active ? 1 : 0); }
    if(role !== undefined){ updates.push('role=?'); params.push(role); }

    if(!updates.length) return res.json({ ok:true });
    params.push(req.params.id);
    await run(`UPDATE users SET ${updates.join(', ')} WHERE id=?`, params);
    res.json({ ok:true });
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

module.exports = router;
