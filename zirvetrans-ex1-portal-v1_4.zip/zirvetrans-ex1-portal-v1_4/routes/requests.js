const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuid } = require('uuid');
const { run, get, all } = require('../db');
const { authRequired, adminOnly } = require('../middleware/auth');
const { sendEmail, sendSms, sendWhatsApp } = require('../notify');

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads')),
  filename: (req, file, cb) => cb(null, uuid() + path.extname(file.originalname))
});
const upload = multer({ storage });

function standardDisplayName({ requestId, source, original }) {
  const ts = new Date().toISOString().replace(/[:.]/g,'-');
  const safeOrig = String(original || 'file').replace(/[\s\/\\]+/g,'_');
  const ext = path.extname(safeOrig);
  const base = safeOrig.slice(0, 60 - ext.length);
  return `${requestId}_${source}_${ts}_${base}${ext}`;
}

router.post('/', authRequired, async (req, res) => {
  try {
    const { exit_office, eori_number, notes } = req.body;
    if (!exit_office || !eori_number) return res.status(400).json({ error: 'Eksik alan var' });

    const id = uuid();
    await run(
      `INSERT INTO requests(id, user_id, exit_office, eori_number, notes, status, created_at)
       VALUES(?,?,?,?,?,?,?)`,
      [id, req.user.id, exit_office, eori_number, notes || '', 'pending', new Date().toISOString()]
    );
    res.json({ id });
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.post('/:id/documents', authRequired, upload.array('files', 10), async (req, res) => {
  try {
    const requestId = req.params.id;
    const reqRow = await get(`SELECT * FROM requests WHERE id=?`, [requestId]);
    if (!reqRow || reqRow.user_id !== req.user.id) return res.status(404).json({ error: 'Talep bulunamadı' });

    const files = req.files || [];
    for (const f of files) {
      const displayName = standardDisplayName({ requestId, source:'customer', original:f.originalname });
      await run(
        `INSERT INTO documents(id, request_id, original_name, display_name, stored_name, mime_type, size_bytes, created_at, source)
         VALUES(?,?,?,?,?,?,?,?,?)`,
        [uuid(), requestId, f.originalname, displayName, f.filename, f.mimetype, f.size, new Date().toISOString(), 'customer']
      );
    }
    res.json({ ok: true, uploaded: files.length });
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.get('/:id/documents', authRequired, async (req, res) => {
  try {
    const requestId = req.params.id;
    const reqRow = await get(`SELECT * FROM requests WHERE id=?`, [requestId]);
    if (!reqRow) return res.status(404).json({ error: 'Talep bulunamadı' });
    if (req.user.role !== 'admin' && reqRow.user_id !== req.user.id) return res.status(403).json({ error: 'Forbidden' });

    const docs = await all(`SELECT id, original_name, display_name, mime_type, size_bytes, created_at, source
                            FROM documents WHERE request_id=?
                            ORDER BY created_at ASC`, [requestId]);
    res.json(docs);
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.post('/:id/admin-documents', authRequired, adminOnly, upload.array('files', 10), async (req, res) => {
  try {
    const requestId = req.params.id;
    const reqRow = await get(`SELECT * FROM requests WHERE id=?`, [requestId]);
    if (!reqRow) return res.status(404).json({ error: 'Talep bulunamadı' });

    const files = req.files || [];
    for (const f of files) {
      const displayName = standardDisplayName({ requestId, source:'admin', original:f.originalname });
      await run(
        `INSERT INTO documents(id, request_id, original_name, display_name, stored_name, mime_type, size_bytes, created_at, source)
         VALUES(?,?,?,?,?,?,?,?,?)`,
        [uuid(), requestId, f.originalname, displayName, f.filename, f.mimetype, f.size, new Date().toISOString(), 'admin']
      );
    }

    const info = await get(`
      SELECT r.id as request_id, r.exit_office, r.eori_number,
             u.full_name, u.company_name, u.phone, u.email
      FROM requests r
      JOIN users u ON u.id = r.user_id
      WHERE r.id = ?
    `, [requestId]);

    if (info) {
      const text = `Merhaba ${info.full_name || ''},
EX1 talebiniz için işlem evrakları yüklendi.

Firma: ${info.company_name}
Talep No: ${info.request_id}
Çıkış Kapısı: ${info.exit_office}
EORI: ${info.eori_number}

Portal üzerinden “Evraklarım” kısmından indirebilirsiniz.
Zirve Trans`;

      await sendEmail({
        to: info.email,
        subject: "EX1 Talebiniz İçin Evrak Yüklendi",
        html: `<p>${text.replace(/\n/g, "<br/>")}</p>`
      });

      await sendWhatsApp({ to: info.phone, body: text });
      const smsTo = info.phone ? `+${String(info.phone).replace(/\D/g,'')}` : null;
      await sendSms({ to: smsTo, body: text });
    }

    res.json({ ok: true, uploaded: files.length });
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.get('/mine', authRequired, async (req, res) => {
  try {
    const rows = await all(
      `SELECT r.*, (SELECT COUNT(*) FROM documents d WHERE d.request_id=r.id) as doc_count
       FROM requests r WHERE r.user_id=? ORDER BY r.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.get('/', authRequired, adminOnly, async (req, res) => {
  try {
    const rows = await all(
      `SELECT r.*, u.company_name, u.full_name, u.phone, u.price_per_request, u.currency,
              (SELECT COUNT(*) FROM documents d WHERE d.request_id=r.id) as doc_count
        FROM requests r JOIN users u ON u.id=r.user_id
        ORDER BY r.created_at DESC`
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.patch('/:id/status', authRequired, adminOnly, async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ['pending', 'in_review', 'approved', 'rejected', 'completed'];
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Geçersiz status' });
    await run(`UPDATE requests SET status=? WHERE id=?`, [status, req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: 'Sunucu hatası' });
  }
});

router.get('/documents/:docId', authRequired, async (req, res) => {
  try {
    const doc = await get(
      `SELECT d.*, r.user_id FROM documents d JOIN requests r ON r.id=d.request_id WHERE d.id=?`,
      [req.params.docId]
    );
    if (!doc) return res.status(404).send('Not found');
    if (req.user.role !== 'admin' && doc.user_id !== req.user.id) return res.status(403).send('Forbidden');
    const filePath = path.join(__dirname, '..', 'uploads', doc.stored_name);
    res.download(filePath, doc.display_name || doc.original_name);
  } catch (e) {
    res.status(500).send('Server error');
  }
});

module.exports = router;
